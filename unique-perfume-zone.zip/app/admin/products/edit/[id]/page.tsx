export default function EditProductPage() {
  return (
    <div className="max-w-5xl">
      <h1 className="mb-8 text-3xl font-bold text-white">
        Edit Product
      </h1>

      <div className="rounded-2xl border border-zinc-800 bg-zinc-900 p-8">
        <p className="text-zinc-400">
          Edit Product page is under development...
        </p>
      </div>
    </div>
  );
}